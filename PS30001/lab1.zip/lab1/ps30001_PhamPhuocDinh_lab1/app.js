let a = 10;
//set a value of 10
console.log("a = "+a)
alert("a ="+a)
var x = prompt("Input n: ");
document.write("X vừa nhập: "+x);